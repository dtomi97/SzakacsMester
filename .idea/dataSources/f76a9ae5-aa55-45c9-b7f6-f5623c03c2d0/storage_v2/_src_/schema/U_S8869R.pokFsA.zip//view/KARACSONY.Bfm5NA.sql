create view KARACSONY as
  select vnev||' '||knev név, count(*)ajándékok from vallalat.z_dolgozo dol
inner join vallalat.z_dolgozik_rajta dr
on dol.szsz=dr.dszsz
group by vnev||' '||knev
/

