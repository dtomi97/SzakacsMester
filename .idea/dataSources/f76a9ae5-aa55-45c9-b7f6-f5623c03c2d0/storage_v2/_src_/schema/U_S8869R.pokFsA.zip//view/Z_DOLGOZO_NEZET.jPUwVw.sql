create view Z_DOLGOZO_NEZET as
  select "VNEV","KNEV","SZSZ","SZDATUM","LAKCIM","NEM","FIZETES","FONOK_SZSZ","OSZ" from vallalat.z_dolgozo
/

