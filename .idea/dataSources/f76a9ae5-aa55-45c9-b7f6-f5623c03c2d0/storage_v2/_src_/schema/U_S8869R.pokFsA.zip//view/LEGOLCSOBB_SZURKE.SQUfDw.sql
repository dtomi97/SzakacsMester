create view LEGOLCSOBB_SZURKE as
  ( select rendszam from (select * from SZERELO.SZ_AUTO
                                                                    where szin = 'szürke'
                                                                    order by elso_vasarlasi_ar)
                                                where rownum = 1)
/

