create view MIKULAS as
  (select vnev, knev, szsz, count(*) as hozzatartozó from z_hozzatartozo hoz
                                    inner join (select * from z_dolgozo) dol
                                    on hoz.DSZSZ = dol.szsz
                                    group by vnev, knev, szsz)
/

